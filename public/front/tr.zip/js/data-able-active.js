// data table active
$('#example').DataTable();
// data table
$('.misco-data-table').wrap("<div class='table-responsive'></div>")